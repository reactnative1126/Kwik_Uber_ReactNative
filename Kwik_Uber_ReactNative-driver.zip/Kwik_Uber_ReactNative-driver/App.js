import React from 'react';
import { AppLoading } from 'expo';
import { Asset } from 'expo-asset';
import * as Font from 'expo-font';
import AppContainer from './src/navigation/AppNavigator';
import { Provider } from 'react-redux';
import { store } from './store';

import * as firebase from 'firebase';

if (!firebase.apps.length) {
  firebase.initializeApp({
    apiKey: "AIzaSyAUp82z2O05zrXAnH8IZ_Nc_NRFg-kPIe4",
    authDomain: "kwik-35758.firebaseapp.com",
    databaseURL: "https://kwik-35758.firebaseio.com",
    projectId: "kwik-35758",
    storageBucket: "kwik-35758.appspot.com",
    messagingSenderId: "823801675801",
    appId: "1:823801675801:web:ddbd391ba348d148a7aa88",
    measurementId: "G-KHE3P3DWD6"
  })
}

export default class App extends React.Component {
  constructor() {
    super();
    console.disableYellowBox = true;
    this.state = {
      assetsLoaded: false,
    };
  }

  _loadResourcesAsync = async () => {
    return Promise.all([
      Asset.loadAsync([
        require('@assets/images/splash.png'),
        require('@assets/images/applogo.png'),
      ]),
      Font.loadAsync({
        'Roboto-Bold': require('@assets/fonts/Roboto-Bold.ttf'),
        'Roboto-Regular': require('@assets/fonts/Roboto-Regular.ttf'),
        'Roboto-Medium': require('@assets/fonts/Roboto-Medium.ttf'),
        'Roboto-Light': require('@assets/fonts/Roboto-Light.ttf'),
      }),
    ]);
  };

  render() {
    return (
      this.state.assetsLoaded ?
        <Provider store={store}>
          <AppContainer />
        </Provider>
        :
        <AppLoading
          startAsync={this._loadResourcesAsync}
          onFinish={() => this.setState({ assetsLoaded: true })}
          onError={console.warn}
          autoHideSplash={true}
        />
    );
  }
}
