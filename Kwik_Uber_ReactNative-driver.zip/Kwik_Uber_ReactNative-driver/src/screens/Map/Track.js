import React from 'react';
import {
    Platform,
    StyleSheet,
    SafeAreaView,
    StatusBar,
    View,
    Dimensions,
    TouchableOpacity,
    Text,
    Alert
} from 'react-native';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { Icon, Button, Avatar } from 'react-native-elements';
import MapView, { Marker, AnimatedRegion, Polyline, PROVIDER_GOOGLE } from "react-native-maps";
import haversine from "haversine";

import { connect } from 'react-redux';

import { Header, Loading } from '@components';
import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';

const { width, height } = Dimensions.get('window');
const ASPECT_RATIO = width / height;
const LATITUDE = 37.771707;
const LONGITUDE = -122.4053769;
const LATITUDE_DELTA = 0.009;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

class Track extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            status: 1,
            data: this.props.navigation.getParam('data'),
            latitude: parseFloat(this.props.navigation.getParam('data').source_lat),
            longitude: parseFloat(this.props.navigation.getParam('data').source_long),
            routeCoordinates: [],
            distanceTravelled: 0,
            prevLatLng: {},
            coordinate: new AnimatedRegion({
                latitude: parseFloat(this.props.navigation.getParam('data').source_lat),
                longitude: parseFloat(this.props.navigation.getParam('data').source_long),
                latitudeDelta: 0,
                longitudeDelta: 0
            })
        };
    }
    componentDidMount() {
        const { coordinate } = this.state;

        this.watchID = navigator.geolocation.watchPosition(
            position => {
                const { routeCoordinates, distanceTravelled } = this.state;
                const { latitude, longitude } = position.coords;
                const newCoordinate = {
                    latitude,
                    longitude
                };
                coordinate.timing(newCoordinate).start();
                this.setState({
                    latitude, longitude,
                    routeCoordinates: routeCoordinates.concat([newCoordinate]),
                    distanceTravelled: distanceTravelled + this.calcDistance(newCoordinate),
                    prevLatLng: newCoordinate
                });
                console.log(routeCoordinates);
            },
            error => console.log(error),
            {
                enableHighAccuracy: true,
                timeout: 20000,
                maximumAge: 1000,
                distanceFilter: 10
            }
        );
    }

    componentWillUnmount() {
        navigator.geolocation.clearWatch(this.watchID);
    };

    getMapRegion = () => ({
        latitude: this.state.latitude,
        longitude: this.state.longitude,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA
    });

    calcDistance = newLatLng => {
        const { prevLatLng } = this.state;
        return haversine(prevLatLng, newLatLng) || 0;
    };

    async onArrived() {
        const { status, data } = this.state;
        if (status == 1) {
            this.setState({ status: 2 });
            Alert.alert(
                "",
                "Are you sure you have arrived at \n pickup location of passenger? \n If yes clieck OK else Cancel.",
                [
                    {
                        text: 'CANCEL',
                        style: 'cancel'
                    },
                    {
                        text: 'OK',
                        onPress: () => {
                            this.setState({
                                status: 3,
                                latitude: parseFloat(data.dest_lat),
                                longitude: parseFloat(data.dest_long)
                            });
                        },
                    }
                ],
            )
        } else if (status == 2) {
            Alert.alert(
                "",
                "Are you sure you have arrived at \n pickup location of passenger? \n If yes clieck OK else Cancel.",
                [
                    {
                        text: 'CANCEL',
                        style: 'cancel'
                    },
                    {
                        text: 'OK',
                        onPress: () => {
                            this.setState({
                                status: 3,
                                latitude: parseFloat(data.dest_lat),
                                longitude: parseFloat(data.dest_long)
                            });
                        },
                    }
                ],
            )
        } else if (status == 3) {
            this.setState({ loading: true });
            await API.post('/start_ride', {
                booking_id: data.riderequest_info.booking_id,
                source_address: data.riderequest_info.source_address,
                source_lat: data.source_lat,
                source_long: data.source_long,
                api_token: this.props.userinfo.api_token
            }).then((resp) => {
                if (resp.data.success == 1) {
                    this.setState({ status: 4, loading: false });
                } else {
                    console.log(resp.data.message);
                    this.setState({ loading: false });
                }
            }).catch((error) => {
                console.log(error);
                this.setState({ loading: false });
            });
        } else {
            this.setState({ loading: true });
            let startLoc = '"' + data.source_lat + ', ' + data.source_long + '"';
            let destLoc = '"' + data.dest_lat + ', ' + data.dest_long + '"';
            let arriveTime = await this.getDriverTime(startLoc, destLoc);
            await API.post('/destination_reached', {
                booking_id: data.riderequest_info.booking_id,
                dest_address: data.riderequest_info.dest_address,
                dest_lat: data.dest_lat,
                dest_long: data.dest_long,
                driving_time: arriveTime.time_in_secs,
                total_kms: arriveTime.distance_in_meter,
                api_token: this.props.userinfo.api_token
            }).then((resp) => {
                if (resp.data.success == 1) {
                    this.setState({ loading: false });
                    this.props.navigation.navigate('Fare');
                } else {
                    console.log(resp.data.message);
                    this.setState({ loading: false });
                }
            }).catch((error) => {
                console.log(error);
                this.setState({loading: false});
            });
        }
    }

    getDriverTime(startLoc, destLoc) {
        return new Promise(function (resolve, reject) {
            fetch(`https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=${startLoc}&destinations=${destLoc}&key=${configs.google_map_key}`)
                .then((response) => response.json())
                .then((res) =>
                    resolve({
                        distance_in_meter: res.rows[0].elements[0].distance.value,
                        time_in_secs: res.rows[0].elements[0].duration.value,
                        timein_text: res.rows[0].elements[0].duration.text
                    })
                )
                .catch(error => {
                    reject(error);
                });
        });
    }

    render() {
        const { status, data } = this.state;
        return (
            <View style={styles.mainViewStyle}>
                <StatusBar translucent backgroundColor="transparent" barStyle="dark-content" />
                <SafeAreaView style={{ flex: 1 }}>
                    <Header title="" isStatus="menu-setup" navigation={this.props.navigation} />
                    <MapView
                        style={styles.map}
                        provider={PROVIDER_GOOGLE}
                        showUserLocation
                        followUserLocation
                        loadingEnabled
                        region={this.getMapRegion()}
                    >
                        <Polyline coordinates={this.state.routeCoordinates} strokeWidth={5} />
                        <Marker.Animated
                            ref={marker => {
                                this.marker = marker;
                            }}
                            coordinate={this.state.coordinate}
                        />
                    </MapView>
                    <View style={{ width: wp('100.0%'), height: 20, backgroundColor: '#FFF' }} />
                    <View style={{ width: wp('100.0%'), height: 50, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ color: '#FFF' }}>
                            {parseFloat(this.state.distanceTravelled).toFixed(2)} km away
                                </Text>
                    </View>
                    <View style={{ width: wp('100.0%'), height: 50, padding: 10, backgroundColor: '#FFF', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <View style={styles.srcCircle} />
                            <Text>{data.riderequest_info.source_address.substring(1, 30)}...</Text>
                        </View>
                    </View>
                    <TouchableOpacity style={styles.rideBtn} onPress={() => this.onArrived()}>
                        <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#FFF' }}>{status == 1 ? 'ARRIVING...' : status == 2 ? 'ARRIVED' : status == 3 ? 'SLIDE TO BEGIN' : 'SLIDE TO END TRIP'}</Text>
                    </TouchableOpacity>
                </SafeAreaView>
                
            </View >
        );
    }
}

const styles = StyleSheet.create({
    mainViewStyle: {
        flex: 1,
        backgroundColor: colors.WHITE,
    },
    container: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: "flex-end",
        alignItems: "center"
    },
    map: {
        ...StyleSheet.absoluteFillObject
    },
    bubble: {
        flex: 1,
        backgroundColor: "rgba(255,255,255,0.7)",
        paddingHorizontal: 18,
        paddingVertical: 12,
        borderRadius: 20
    },
    latlng: {
        width: 200,
        alignItems: "stretch"
    },
    button: {
        width: 80,
        paddingHorizontal: 12,
        alignItems: "center",
        marginHorizontal: 10
    },
    buttonContainer: {
        flexDirection: "row",
        marginVertical: 20,
        backgroundColor: "transparent"
    },
    srcCircle: {
        marginLeft: 10, marginRight: 10,
        width: 10,
        height: 10,
        backgroundColor: '#04B273',
        borderRadius: 10,
        shadowColor: '#00F561',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 10,
    },
    rideBtn: {
        position: 'absolute',
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: wp('100.0%'),
        height: 50,
        backgroundColor: '#00963D',
        shadowColor: '#000',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 5,
    },
});

const mapStateToProps = state => {
    return {
        logged: state.account.logged,
        userinfo: state.account.userinfo
    }
}
export default connect(mapStateToProps, undefined)(Track)