import React from 'react';
import {
    StyleSheet,
    SafeAreaView,
    StatusBar,
    View,
    Image,
    Text
} from 'react-native';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { Icon } from 'react-native-elements';
import * as Constants from 'expo-constants';
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import ToggleSwitch from 'toggle-switch-react-native';

import { connect } from 'react-redux';
import { setUser } from '@modules/account/actions';

import { Header, Loading } from '@components';
import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';

class Map extends React.Component {
    bonusAmmount = 0;
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            region: {
                latitude: 9.061460,
                longitude: 7.500640,
                latitudeDelta: 0.9922,
                longitudeDelta: 0.9421,
            },
            address: null,
            active: false,
        }
    }

    async componentDidMount() {
        let { status } = await Permissions.askAsync(Permissions.LOCATION);
        if (status !== 'granted') {
            this.setState({
                errorMessage: 'Permission to access location was denied',
            });
        }
        let location = await Location.getCurrentPositionAsync({});
        if (location) {
            var pos = {
                latitude: location.coords.latitude,
                longitude: location.coords.longitude,
            };

            if (pos) {
                let latlng = pos.latitude + ',' + pos.longitude;
                fetch('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latlng + '&key=' + configs.google_map_key)
                    .then((response) => response.json())
                    .then((responseJson) => {
                        this.setState({
                            region: {
                                latitude: pos.latitude,
                                longitude: pos.longitude,
                                latitudeDelta: 0.9922,
                                longitudeDelta: 0.9421
                            },
                            address: responseJson.results[0].formatted_address
                        });
                    })
                    .catch((error) => {
                        console.error(error);
                    })
            }
        }
        if (this.props.userinfo.availability == 1) {
            this.setState({ active: true });
        } else {
            this.setState({ active: false });
        }

        setInterval(() => {
            this.setLatLong();
        }, 30000)
    }

    async setLatLong() {
        let location = await Location.getCurrentPositionAsync({});
        if (location) {
            API.post('/submit_driver_location', {
                driver_id: this.props.userinfo.user_id,
                api_token: this.props.userinfo.api_token,
                driver_lat: location.coords.latitude,
                driver_long: location.coords.longitude
            }).then((resp) => {

            }).catch((error) => {
                console.log(error);
                // this.setState({loading: false});
            });
        }
    }

    async onLine(isOn) {
        this.setState({ loading: true });
        await API.post('/change_availability', {
            user_id: this.props.userinfo.user_id,
            availability: isOn == true ? 1 : 0,
            api_token: this.props.userinfo.api_token
        }).then((resp) => {
            if (resp.data.success == 1) {
                let { userinfo } = this.props;
                userinfo.availability = isOn == true ? 1 : 0
                this.setState({ loading: false, active: isOn });
                this.props.setUser(userinfo);
            } else {
                alert(resp.data.message);
                this.setState({ loading: false });
            }
        }).catch((error) => {
            console.log(error);
            this.setState({ loading: false });
        });
    }


    render() {
        return (
            <View style={styles.mainViewStyle} >
                <StatusBar translucent backgroundColor="transparent" barStyle="dark-content" />
                <SafeAreaView style={{ flex: 1 }}>
                    <Header title="" isStatus="menu" navigation={this.props.navigation} />
                    <MapView
                        provider={PROVIDER_GOOGLE}
                        showsUserLocation={true}
                        loadingEnabled
                        showsMyLocationButton={false}
                        region={this.state.region}
                        style={[styles.map, { marginBottom: 0 }]}
                        onMapReady={() => this.setState({ marginBottom: 1 })}
                    >
                        <Marker.Animated
                            coordinate={{ latitude: parseFloat(this.state.region.latitude), longitude: parseFloat(this.state.region.longitude) }}
                            image={require('@assets/images/available_car.png')}
                        ></Marker.Animated>
                    </MapView>
                    <View style={styles.black}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <Image
                                source={this.props.userinfo.profile_pic == null ? images.img_avatar : { uri: configs.baseURL + '/uploads/' + this.props.userinfo.profile_pic }}
                                style={styles.imageStyle}
                            />
                            <View style={{ marginLeft: 10, width: wp('50.0%') }}>
                                <Text style={{ fontSize: 18 }}>{this.props.userinfo.user_name}</Text>
                                {/* <Text style={{ fontSize: 18, fontWeight: 'bold' }}>{this.props.userinfo.vehicle_info.make} {this.props.userinfo.vehicle_info.model}</Text> */}
                                <Text style={{ fontSize: 12, color: '#888' }}>{this.state.address}</Text>
                            </View>
                        </View>
                        <View style={{ height: '100%', alignItems: 'center' }}>
                            <ToggleSwitch
                                isOn={this.state.active}
                                onColor={'#01A457'}
                                offColor={'#F1362F'}
                                size="small"
                                onToggle={isOn => this.onLine(isOn)}
                            />
                            <Text style={{ fontSize: 8, color: '#888' }}>{"GO ONLINE"}</Text>
                        </View>
                    </View>
                </SafeAreaView>
                <Loading loading={this.state.loading} title={"Loading..."} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    black: {
        position: 'absolute',
        bottom: 0,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: wp('100.0%'),
        height: 120,
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        backgroundColor: colors.WHITE,
        shadowColor: '#000',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 5,
        padding: 20
    },
    mainViewStyle: {
        flex: 1,
        backgroundColor: colors.WHITE,
    },
    map: {
        flex: 1,
        ...StyleSheet.absoluteFillObject,
    },
    imageStyle: {
        width: 80,
        height: 80,
        borderRadius: 40
    }
});

const mapStateToProps = state => {
    return {
        logged: state.account.logged,
        userinfo: state.account.userinfo
    }
}
const mapDispatchToProps = dispatch => {
    return {
        setUser: (data) => {
            dispatch(setUser(data))
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Map)