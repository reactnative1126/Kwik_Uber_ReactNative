import React, { Component } from "react";
import {
  ActivityIndicator,
  StyleSheet,
  View,
  AsyncStorage,
  Alert
} from 'react-native';
import { Platform } from 'react-native';
import { NavigationActions } from 'react-navigation';
import { Notifications } from 'expo';
import * as Permissions from 'expo-permissions';
import Constants from 'expo-constants';
import { Audio } from 'expo-av';

import { connect } from 'react-redux';
import { setUser, setDeviceToken } from '@modules/account/actions';

class AuthStart extends Component {
  constructor(props) {
    super(props);

  }

  async componentWillMount() {
    this.registerForPushNotificationsAsync();
    this.notificationListener = Notifications.addListener(this.notificationListen);

    if (await AsyncStorage.getItem('LOGGED') === 'true') {
      let userinfo = await AsyncStorage.getItem('USER');
      this.props.setUser(userinfo);
      this.props.navigation.navigate('Root');
    } else {
      this.props.navigation.navigate('Auth');
    }
  }
  componentWillUnmount() {
    // this.notificationListener = Notifications.removeListener(this.notificationListen);
  }

  async registerForPushNotificationsAsync() {
    if (Constants.isDevice) {
      const { status: existingStatus } = await Permissions.getAsync(
        Permissions.NOTIFICATIONS
      );
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        alert('Failed to get push token for push notification!');
        return;
      }
      if (Platform.OS === 'android') {
        Notifications.createChannelAndroidAsync('default', {
          name: 'Android Channel',
          sound: true,
          vibrate: true
        });
      }
      let deviceToken = await Notifications.getExpoPushTokenAsync();
      this.props.setDeviceToken(deviceToken);
    } else {
      alert('Must use physical device for Push Notifications');
    }
  }

  notificationListen = async (notification) => {
    console.log(notification);
    if (notification.data.data.success == 1) {
      Alert.alert(
        notification.data.data.title,
        notification.data.data.description + "\n\n" +
        "Customer Name: " + notification.data.data.customer_name + "\n\n" +
        "Pickup Location:\n" + notification.data.data.data.riderequest_info.source_address + "\n\n" +
        "Destination Address:\n" + notification.data.data.data.riderequest_info.dest_address + "\n",
        [
          {
            text: 'DECLINE',
            onPress: () => {
              alert("OK");
            },
            style: 'cancel'
          },
          {
            text: 'ACCEPT',
            onPress: () => {
              const navigatieAction = NavigationActions.navigate({
                routeName: 'Track',
                params: {
                  data: notification.data.data.data
                }
              });
              this.props.navigation.dispatch(navigatieAction);
            },
          }
        ],
      )
    }
    const soundObject = new Audio.Sound();
    try {
      await soundObject.loadAsync(require('@assets/sounds/car_horn.wav'));
      await soundObject.playAsync();
    } catch (error) {
      console.log("Unable to play shound");
    }
  };

  // Render any loading content that you like here
  render() {
    return (
      <View style={styles.IndicatorStyle}>
        <ActivityIndicator size="large" />
      </View>
    );
  }
}

//Screen Styling
const styles = StyleSheet.create({
  IndicatorStyle: {
    flex: 1,
    justifyContent: "center"
  }
})

const mapDispatchToProps = dispatch => {
  return {
    setUser: (data) => {
      dispatch(setUser(data))
    },
    setDeviceToken: (data) => {
      dispatch(setDeviceToken(data))
    }
  }
}
export default connect(undefined, mapDispatchToProps)(AuthStart)