export default {
    baseURL: "http://192.168.100.52",
    apiURL: "http://192.168.100.52/api",
    google_map_key: 'AIzaSyCMy3xkYnOsrfiAV8ogLH6UV19ICscgFZ4',
    cloud_function_server_url: 'https://us-central1-taivla.cloudfunctions.net/'
}