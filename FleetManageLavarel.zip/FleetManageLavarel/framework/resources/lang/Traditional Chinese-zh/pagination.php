<?php

return [

	'previous' => '&laquo; 以前',
	'next' => '下一個 &raquo;',

];
