<?php

return [

	'failed' => '這些憑證與我們的記錄不符.',
	'throttle' => '登錄嘗試過多。 請再次嘗試:seconds秒.',

];
