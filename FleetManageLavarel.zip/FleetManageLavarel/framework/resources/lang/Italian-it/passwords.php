<?php

return [

	'password' => 'Le Password devo essere almeno di sei caratteri e deve essere uguale alla conferma.',
	'reset' => 'La password è stata resettata!',
	'sent' => 'Abbiamo inviato le istruzioni per il cambio password nella tua casella email!',
	'token' => 'Il token di cambio password nonv valido.',
	'user' => "Non è presenete nessun utente con questo indirizzo e-mail.",

];
