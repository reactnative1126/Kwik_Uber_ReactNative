<?php

return [

	'previous' => '&laquo; السابق',
	'next' => 'التالى &raquo;',

];
