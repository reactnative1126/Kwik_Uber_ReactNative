<?php

return [

	'failed' => 'Diese Anmeldeinformationen stimmen nicht mit unseren Unterlagen überein.',
	'throttle' => 'Zu viele Login-Versuche. Bitte versuchen Sie es erneut :seconds Sekunden.',

];
