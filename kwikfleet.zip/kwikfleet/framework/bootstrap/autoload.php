<?php

define('LARAVEL_START', microtime(true));

require __DIR__ . '/../vendor/autoload.php';
