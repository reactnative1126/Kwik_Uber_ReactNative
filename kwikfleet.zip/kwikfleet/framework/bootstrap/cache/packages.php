<?php return array (
  'brozot/laravel-fcm' => 
  array (
    'providers' => 
    array (
      0 => 'LaravelFCM\\FCMServiceProvider',
    ),
    'aliases' => 
    array (
      'FCM' => 'LaravelFCM\\Facades\\FCM',
      'FCMGroup' => 'LaravelFCM\\Facades\\FCMGroup',
    ),
  ),
  'cyber-duck/laravel-excel' => 
  array (
    'providers' => 
    array (
      0 => 'Cyberduck\\LaravelExcel\\ExcelServiceProvider',
    ),
  ),
  'davibennun/laravel-push-notification' => 
  array (
    'providers' => 
    array (
      0 => 'Davibennun\\LaravelPushNotification\\LaravelPushNotificationServiceProvider',
    ),
    'aliases' => 
    array (
      'PushNotification' => 'Davibennun\\LaravelPushNotification\\Facades\\PushNotification',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravelcollective/html' => 
  array (
    'providers' => 
    array (
      0 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
);