<?php

return [

	'password' => 'Passwörter müssen mindestens sechs Zeichen und entsprechen der Bestätigung.',
	'reset' => 'Dein Passwort wurde zurück gesetzt!',
	'sent' => 'Wir haben Ihren Passwort zurückgesetzt!',
	'token' => 'Dieses Passwort-Reset-Token ist ungültig.',
	'user' => "Wir können einen Benutzer nicht mit dieser E-Mail-Adresse finden.",

];

