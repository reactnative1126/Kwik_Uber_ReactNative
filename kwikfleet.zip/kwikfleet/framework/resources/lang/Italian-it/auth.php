<?php

return [

	'failed' => 'Le credenziali non sono corrette.',
	'throttle' => 'Troppi tentativi di accesso. Riptrova tra :seconds seconds.',

];
