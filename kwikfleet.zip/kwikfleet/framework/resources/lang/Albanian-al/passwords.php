<?php

return [

	'password' => 'Fjalkalimet duhet te jen se me paku 6 karaktere dhe te perputhen me konfirmimin.',
	'reset' => 'Fjalkalimi juaj eshte risetuar!',
	'sent' => 'Eshte nisur linku per ristim te fjalkalimit me email!',
	'token' => 'Ky token per risetim te fjalkalimit eshte jovalid.',
	'user' => "Nuk mund te gjejm perdorues me ate email adrese.",

];
