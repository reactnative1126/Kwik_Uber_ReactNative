<?php

return [

	'failed' => 'Keto shenime nuk jan te shenuara bazen tone.',
	'throttle' => 'Shum tentime per tu loguar. Ju lutem provoni prap pas :seconds seconds.',

];
