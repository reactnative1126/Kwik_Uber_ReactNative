export default {
    baseURL: "http://kwikbookings.com",
    apiURL: "http://kwikbookings.com/api",
    google_map_key: 'AIzaSyCXU9mYBzIVbb3ljhHbwWj1IHAP373_RO4',
    facebook_app_id: '1643080409184364',
    cloud_function_server_url: 'https://us-central1-taivla.cloudfunctions.net/'
}
