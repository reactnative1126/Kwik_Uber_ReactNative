import React, { Component } from "react";
import {
    View,
} from "react-native";
import { Icon } from 'react-native-elements'

export default class Rating extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        const { rating, color, size } = this.props;
        return (
            <View style={{ flexDirection: 'row' }}>
                {rating >= 1 ? <Icon name='star' type='font-awesome' color={color} size={size} /> : rating >= 0.5 ? <Icon name='star-half-o' type='font-awesome' color={color} size={size} /> : <Icon name='star-o' type='font-awesome' color='#D8D8D8' size={size} />}
                {rating >= 2 ? <Icon name='star' type='font-awesome' color={color} size={size} /> : rating >= 1.5 ? <Icon name='star-half-o' type='font-awesome' color={color} size={size} /> : <Icon name='star-o' type='font-awesome' color='#D8D8D8' size={size} />}
                {rating >= 3 ? <Icon name='star' type='font-awesome' color={color} size={size} /> : rating >= 2.5 ? <Icon name='star-half-o' type='font-awesome' color={color} size={size} /> : <Icon name='star-o' type='font-awesome' color='#D8D8D8' size={size} />}
                {rating >= 4 ? <Icon name='star' type='font-awesome' color={color} size={size} /> : rating >= 3.5 ? <Icon name='star-half-o' type='font-awesome' color={color} size={size} /> : <Icon name='star-o' type='font-awesome' color='#D8D8D8' size={size} />}
                {rating >= 5 ? <Icon name='star' type='font-awesome' color={color} size={size} /> : rating >= 4.5 ? <Icon name='star-half-o' type='font-awesome' color={color} size={size} /> : <Icon name='star-o' type='font-awesome' color='#D8D8D8' size={size} />}
            </View>
        );
    }
}