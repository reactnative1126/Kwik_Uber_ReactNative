import types from './types';

const initialState = {
    logged: false,
    device_token: null,
    userinfo: {
        user_id: 8,
        api_token: "VIN8qvWuLFgfMUgMho02e3Yb8rxzSqWHrrpSWUsk31mP1E2BsB148se1CIf5",
        fcm_id: null,
        device_token: null,
        socialmedia_uid: "",
        user_name: "Dan Matei",
        user_type: "D",
        mobno: "16685466",
        phone_code: "+93",
        email: "danmtplay@gmail.com",
        gender: "1",
        password: "$2y$10$8fmlBTe5TmAIttXA2wleqePb9XExN6LMNJYk9SKQIysGxY.thTq6S",
        profile_pic: "df732a0e-491a-4664-abd5-10c2a0032e33.jpg",
        address: "199 Valencia St, San Francisco, CA 94103",
        idproof: "d8701a4f-cc9a-45eb-9471-fd2081fd9b42.jpg",
        idproof_type: "License",
        vehicle_number: "11111",
        vehicle_info: {
            id: 3,
            make: "Mercedes",
            model: "Benz",
            type: null,
            year: "1990",
            group_id: 1,
            lic_exp_date: "2020-06-30",
            reg_exp_date: "2020-06-30",
            vehicle_image: null,
            engine_type: "Petrol",
            horse_power: "100",
            color: "green",
            vin: "11111",
            license_plate: "11111",
            mileage: null,
            in_service: null,
            user_id: 1,
            created_at: "2020-06-09 13:06:11",
            updated_at: "2020-06-09 13:06:11",
            deleted_at: null,
            int_mileage: 20,
            type_id: 2,
            fleetio_id: 0,
            meta_data: {
                ins_number: "",
                ins_exp_date: "",
                documents: "",
                udf: "N;",
                average: "10",
                driver_id: "8"
            }
        },
        availability: "1",
        status: 1,
        wallet_balance: 0,
        timestamp: "2020-06-07 16:35:39"
    }
}

export default function accountReducer(state = initialState, action) {
    switch (action.type) {
        case types.SET_USER:
            return {
                ...state,
                logged: true,
                userinfo: action.payload
            };
        case types.SET_DEVICE_TOKEN:
            return {
                ...state,
                device_token: action.payload
            };
        case types.SIGN_OUT:
            return {
                ...state,
                logged: false,
                userinfo: initialState
            }

        default:
            return state;
    }
}