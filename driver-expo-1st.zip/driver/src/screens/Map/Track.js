import React from 'react';
import {
    Platform,
    StyleSheet,
    SafeAreaView,
    StatusBar,
    View,
    Dimensions,
    TouchableOpacity,
    Text,
    Image,
    Linking
} from 'react-native';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { Icon, Button, Avatar } from 'react-native-elements';
import MapView, { Marker, AnimatedRegion, Polyline, PROVIDER_GOOGLE } from "react-native-maps";
import haversine from "haversine";
import * as Permissions from 'expo-permissions';
import * as Location from 'expo-location';

import { connect } from 'react-redux';

import { Header, Loading, Rating } from '@components';
import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';

const { width, height } = Dimensions.get('window');
const ASPECT_RATIO = width / height;
const LATITUDE = 37.771707;
const LONGITUDE = -122.4053769;
const LATITUDE_DELTA = 0.055;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

class Track extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: false,
            status: 1,
            menu: false,
            data: this.props.navigation.getParam('data'),
            latitude: parseFloat(this.props.navigation.getParam('data').data.source_lat),
            longitude: parseFloat(this.props.navigation.getParam('data').data.source_long),
            routeCoordinates: [],
            distanceTravelled: 0,
            prevLatLng: {},
            coordinate: new AnimatedRegion({
                latitude: parseFloat(this.props.navigation.getParam('data').data.source_lat),
                longitude: parseFloat(this.props.navigation.getParam('data').data.source_long),
                latitudeDelta: 0,
                longitudeDelta: 0
            })
        };
    }
    componentDidMount() {
        const { coordinate } = this.state;
        this.watchID = navigator.geolocation.watchPosition(
            position => {
                const { routeCoordinates, distanceTravelled } = this.state;
                const { latitude, longitude } = position.coords;
                const newCoordinate = {
                    latitude,
                    longitude
                };
                coordinate.timing(newCoordinate).start();
                this.setState({
                    latitude, longitude,
                    routeCoordinates: routeCoordinates.concat([newCoordinate]),
                    distanceTravelled: distanceTravelled + this.calcDistance(newCoordinate),
                    prevLatLng: newCoordinate
                });
                console.log(routeCoordinates);
            },
            error => console.log(error),
            {
                enableHighAccuracy: true,
                timeout: 20000,
                maximumAge: 1000,
                distanceFilter: 10
            }
        );
    }

    componentWillUnmount() {
        navigator.geolocation.clearWatch(this.watchID);
    };

    getMapRegion = () => ({
        latitude: this.state.latitude,
        longitude: this.state.longitude,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA
    });

    calcDistance = newLatLng => {
        const { prevLatLng } = this.state;
        return haversine(prevLatLng, newLatLng) || 0;
    };

    async onArrived() {
        const { status, data } = this.state;
        if (status == 1) {
            this.setState({ status: 2 });
        } else if (status == 3) {
            this.setState({ status: 4, loading: true });
            let { status } = await Permissions.askAsync(Permissions.LOCATION);
            if (status !== 'granted') {
                this.setState({
                    errorMessage: 'Permission to access location was denied',
                });
            }
            let location = await Location.getCurrentPositionAsync({});
            if (location) {
                var pos = {
                    latitude: location.coords.latitude,
                    longitude: location.coords.longitude,
                };
                if (pos) {
                    let latlng = pos.latitude + ',' + pos.longitude;
                    fetch('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latlng + '&key=' + configs.google_map_key)
                        .then((response) => response.json())
                        .then((responseJson) => {
                            this.setState({
                                source_lat: pos.latitude,
                                source_long: pos.longitude
                            })
                            API.post('/start_ride', {
                                booking_id: data.data.riderequest_info.booking_id,
                                source_address: responseJson.results[0].formatted_address,
                                source_lat: pos.latitude,
                                source_long: pos.longitude,
                                api_token: this.props.userinfo.api_token
                            }).then((resp) => {
                                if (resp.data.success == 1) {
                                    this.setState({ status: 4, loading: false });
                                } else {
                                    console.log(resp.data.message);
                                    this.setState({ loading: false });
                                }
                            }).catch((error) => {
                                console.log(error);
                                this.setState({ loading: false });
                            });
                        }).catch((error) => {
                            console.error(error);
                        })
                }
            }
        } else if (status == 4) {
            this.setState({ loading: true });
            let { status } = await Permissions.askAsync(Permissions.LOCATION);
            if (status !== 'granted') {
                this.setState({
                    errorMessage: 'Permission to access location was denied',
                });
            }
            let location = await Location.getCurrentPositionAsync({});
            if (location) {
                var pos = {
                    latitude: location.coords.latitude,
                    longitude: location.coords.longitude,
                };
                if (pos) {
                    let latlng = pos.latitude + ',' + pos.longitude;
                    fetch('https://maps.googleapis.com/maps/api/geocode/json?latlng=' + latlng + '&key=' + configs.google_map_key)
                        .then((response) => response.json())
                        .then((responseJson) => {
                            let startLoc = '"' + this.state.source_lat + ', ' + this.state.source_long + '"';
                            let destLoc = '"' + pos.latitude + ', ' + pos.longitude + '"';
                            let arriveTime = this.getDriverTime(startLoc, destLoc);
                            API.post('/destination_reached', {
                                booking_id: data.data.riderequest_info.booking_id,
                                dest_address: responseJson.results[0].formatted_address,
                                dest_lat: pos.latitude,
                                dest_long: pos.longitude,
                                driving_time: arriveTime.time_in_secs,
                                total_kms: arriveTime.distance_in_meter,
                                api_token: this.props.userinfo.api_token
                            }).then((resp) => {
                                if (resp.data.success == 1) {
                                    this.setState({ loading: false });
                                    this.props.navigation.navigate('Review', {data: resp.data});
                                } else {
                                    console.log(resp.data.message);
                                    this.setState({ loading: false });
                                }
                            }).catch((error) => {
                                console.log(error);
                                this.setState({ loading: false });
                            });
                        }).catch((error) => {
                            console.error(error);
                        })
                }
            }
        }
    }

    getDriverTime(startLoc, destLoc) {
        return new Promise(function (resolve, reject) {
            fetch(`https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=${startLoc}&destinations=${destLoc}&key=${configs.google_map_key}`)
                .then((response) => response.json())
                .then((res) =>
                    resolve({
                        distance_in_meter: res.rows[0].elements[0].distance.value,
                        time_in_secs: res.rows[0].elements[0].duration.value,
                        timein_text: res.rows[0].elements[0].duration.text
                    })
                )
                .catch(error => {
                    reject(error);
                });
        });
    }

    renderAlert() {
        const { data } = this.state;
        return (
            <View style={{
                position: 'absolute',
                justifyContent: 'center',
                alignItems: 'center',
                width: wp('100.0%'),
                height: hp('100.0%'),
                backgroundColor: '#000000BF',
                zIndex: 1001
            }}>
                <View style={{
                    width: '90%',
                    height: 250,
                    backgroundColor: '#FFF',
                    borderRadius: 10,
                    alignItems: 'center'
                }}>
                    <View style={{ justifyContent: 'center', alignItems: 'center', marginTop: 40, padding: 20 }}>
                        <Text style={{ color: '#555', marginBottom: 10, textAlign: 'center', fontSize: 18 }}>{'Are you sure you have arrived at pickup location of passenger? If yes click OK else Cancel.'}</Text>
                    </View>

                    <View style={{ flexDirection: 'row', width: '100%' }}>
                        <TouchableOpacity style={[styles.rideBtn1, { backgroundColor: '#A8A8A8' }]} onPress={() => {
                            this.setState({
                                status: 1,
                                latitude: parseFloat(data.data.dest_lat),
                                longitude: parseFloat(data.data.dest_long)
                            })
                        }}>
                            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#FFF' }}>CANCEL</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.rideBtn1} onPress={() => {
                            this.setState({
                                status: 3,
                                latitude: parseFloat(data.data.dest_lat),
                                longitude: parseFloat(data.data.dest_long)
                            })
                        }}>
                            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#FFF' }}>OK</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }

    renderDetails() {
        const { data } = this.state;
        return (
            <View style={{
                position: 'absolute',
                justifyContent: 'center',
                alignItems: 'center',
                width: wp('100.0%'),
                height: hp('100.0%'),
                backgroundColor: '#000000BF',
                zIndex: 1001
            }}>
                <View style={{
                    width: '90%',
                    height: 350,
                    backgroundColor: '#FFF',
                    borderRadius: 10,
                    alignItems: 'center'
                }}>
                    <View style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        paddingLeft: 20, paddingRight: 20,
                        width: '100%',
                        height: 50,
                        borderBottomWidth: 1,
                        borderBottomColor: '#DDD'
                    }}>
                        <View />
                        <Text style={{ fontSize: 18, marginVertical: 2 }}>{'Passenger Details'}</Text>
                        <TouchableOpacity onPress={() => this.setState({ menu: false })}>
                            <Icon name='close-circle-outline' type='material-community' size={25} />
                        </TouchableOpacity>
                    </View>
                    <Image source={data.profile_pic == null ? images.img_avatar : {uri: configs.baseUrl + '/uploads/' + data.profile_pic}} style={{ width: 100, height: 100, borderRadius: 50, marginTop: 20 }} />
                    <View style={{ justifyContent: 'center', alignItems: 'center', marginTop: 20, marginBottom: 20 }}>
                        <Text style={{ fontSize: 16, fontWeight: 'bold' }}>{data.customer_name}</Text>
                    </View>
                    {/* <Rating rating={4.5} color='#FFCC01' size={40} /> */}

                    <View style={{ flexDirection: 'row', width: '100%', marginTop: 20 }}>
                        <TouchableOpacity style={styles.rideBtn2} onPress={() => this.props.navigation.navigate('Message', {data: data})}>
                            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#00963D' }}>MESSAGE</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.rideBtn2} onPress={() => Linking.openURL(`tel:+8613654189798`)}>
                            <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#00963D' }}>CALL</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }


    render() {
        const { status, data } = this.state;
        return (
            <View style={styles.mainViewStyle}>
                <StatusBar translucent backgroundColor="transparent" barStyle="dark-content" />
                <SafeAreaView style={{ flex: 1 }}>
                    <Header title="" isStatus="menu-setup" navigation={this.props.navigation} onPress={() => this.setState({ menu: true })} />
                    <MapView
                        style={styles.map}
                        provider={PROVIDER_GOOGLE}
                        showUserLocation
                        followUserLocation
                        loadingEnabled
                        region={this.getMapRegion()}
                    >
                        <MapView.Polyline
                            coordinates={this.state.coords ? this.state.coords : [{ latitude: 0.00, longitude: 0.00 }]}
                            strokeWidth={5}
                            strokeColor={'#FF0000'}
                        />
                        <Polyline coordinates={this.state.routeCoordinates} strokeWidth={5} />
                        <Marker.Animated
                            ref={marker => {
                                this.marker = marker;
                            }}
                            image={require('@assets/images/track_Car.png')}
                            coordinate={new AnimatedRegion({
                                latitude: this.state.latitude ? this.state.latitude : 0.00,
                                longitude: this.state.longitude ? this.state.longitude : 0.00,
                                latitudeDelta: LATITUDE_DELTA,
                                longitudeDelta: LONGITUDE_DELTA
                            })}
                        >
                        </Marker.Animated>
                        <Marker
                            image={require('@assets/images/rsz_2red_pin.png')}
                            coordinate={{
                                latitude: this.props.navigation.getParam('data').data.source_lat ? parseFloat(this.props.navigation.getParam('data').data.source_lat) : 0.00,
                                longitude: this.props.navigation.getParam('data').data.source_long ? parseFloat(this.props.navigation.getParam('data').data.source_long) : 0.00
                            }}
                        >
                        </Marker>
                        <Marker
                            image={require('@assets/images/rsz_2red_pin.png')}
                            coordinate={{
                                latitude: this.props.navigation.getParam('data').data.dest_lat ? parseFloat(this.props.navigation.getParam('data').data.dest_lat) : 0.00,
                                longitude: this.props.navigation.getParam('data').data.dest_long ? parseFloat(this.props.navigation.getParam('data').data.dest_long) : 0.00
                            }}
                        >
                        </Marker>
                    </MapView>
                    <View style={{ width: wp('100.0%'), height: 20, backgroundColor: '#FFF' }} />
                    <View style={{ width: wp('100.0%'), height: 50, backgroundColor: '#000', justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ color: '#FFF' }}>
                            {parseFloat(this.state.distanceTravelled).toFixed(2)} km away
                                </Text>
                    </View>
                    <View style={{ width: wp('100.0%'), height: 50, padding: 10, backgroundColor: '#FFF', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                            <View style={styles.srcCircle} />
                            <Text>{data.data.riderequest_info.source_address.substring(1, 30)}...</Text>
                        </View>
                    </View>
                    <TouchableOpacity style={styles.rideBtn} onPress={() => this.onArrived()}>
                        <Text style={{ fontSize: 18, fontWeight: 'bold', color: '#FFF' }}>{status == 1 ? 'ARRIVING...' : status == 2 ? 'ARRIVED' : status == 3 ? 'SLIDE TO BEGIN' : 'SLIDE TO END TRIP'}</Text>
                    </TouchableOpacity>
                </SafeAreaView>
                {this.state.status == 2 ? this.renderAlert() : null}
                {this.state.menu ? this.renderDetails() : null}
                <Loading loading={this.state.loading} title={"Loading..."} />
            </View >
        );
    }
}

const styles = StyleSheet.create({
    mainViewStyle: {
        flex: 1,
        backgroundColor: colors.WHITE,
    },
    container: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: "flex-end",
        alignItems: "center"
    },
    map: {
        ...StyleSheet.absoluteFillObject
    },
    bubble: {
        flex: 1,
        backgroundColor: "rgba(255,255,255,0.7)",
        paddingHorizontal: 18,
        paddingVertical: 12,
        borderRadius: 20
    },
    latlng: {
        width: 200,
        alignItems: "stretch"
    },
    button: {
        width: 80,
        paddingHorizontal: 12,
        alignItems: "center",
        marginHorizontal: 10
    },
    buttonContainer: {
        flexDirection: "row",
        marginVertical: 20,
        backgroundColor: "transparent"
    },
    srcCircle: {
        marginLeft: 10, marginRight: 10,
        width: 10,
        height: 10,
        backgroundColor: '#04B273',
        borderRadius: 10,
        shadowColor: '#00F561',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 10,
    },
    rideBtn: {
        position: 'absolute',
        bottom: 0,
        justifyContent: 'center',
        alignItems: 'center',
        width: wp('100.0%'),
        height: 50,
        backgroundColor: '#00963D',
        shadowColor: '#000',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 5,
    },
    rideBtn1: {
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 20,
        marginTop: 5,
        marginBottom: 5,
        width: '40%',
        height: 50,
        borderRadius: 10,
        backgroundColor: '#00963D',
        shadowColor: '#000',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 5,
    },
    rideBtn2: {
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 20,
        marginTop: 5,
        marginBottom: 5,
        width: '40%',
        height: 50,
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#DDD',
    },
});

const mapStateToProps = state => {
    return {
        logged: state.account.logged,
        userinfo: state.account.userinfo
    }
}
export default connect(mapStateToProps, undefined)(Track)