import React, { Component } from "react";
import {
    Platform,
    StyleSheet,
    SafeAreaView,
    ImageBackground,
    View,
    Image,
    Text,
    TouchableOpacity,
    StatusBar,
    AsyncStorage
} from "react-native";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Icon, Input } from 'react-native-elements';
import * as Facebook from 'expo-facebook';
import * as Location from 'expo-location';
import * as Permissions from 'expo-permissions';
import Geocoder from 'react-native-geocoding';

import { connect } from 'react-redux';
import { setUser } from '@modules/account/actions';

import { Header, Loading } from '@components';
import MaterialButtonYellow from "@components/MaterialButtonYellow";
import { verifyEmail, verifyLength } from '@constants/functions';
import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';
import * as firebase from 'firebase';

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            email: null,
            password: null,
            emailMsg: null,
            passwordMsg: null,
            loading: false,
        }
    }

    async FbLogin() {
        try {
            let { status } = await Permissions.askAsync(Permissions.LOCATION);
            if (status !== 'granted') {
                alert('Permission to access location was denied');
            }
            let location = await Location.getCurrentPositionAsync({})
            Geocoder.init(configs.google_map_key);

            await Facebook.initializeAsync(configs.facebook_app_id);
            const {
                type,
                token
            } = await Facebook.logInWithReadPermissionsAsync({
                permissions: ['public_profile', "email"],
            });
            if (type === 'success') {
                this.setState({ loading: true });
                const credential = firebase.auth.FacebookAuthProvider.credential(token);
                firebase.auth().signInWithCredential(credential)
                    .then((resp) => {
                        if (resp) {
                            if (resp.additionalUserInfo.isNewUser == true) {
                                Geocoder.from({
                                    latitude: location.coords.latitude,
                                    longitude: location.coords.longitude
                                }).then(json => {
                                    API.post('/user_register', {
                                        user_type: 'D',
                                        user_name: resp.user.displayName,
                                        user_uid: resp.user.uid,
                                        email: resp.user.email,
                                        mobno: resp.user.phoneNumber == null ? '123456789' : resp.user.phoneNumber,
                                        password: '123456',
                                        // licence_image: resp.user.photoURL,
                                        gender: 1,
                                        address: json.results[0].formatted_address,
                                        mode: Platform.OS,
                                        fcm_id: this.props.device_token,
                                        device_token: this.props.device_token
                                    }).then((response) => {
                                        if (response.data.success == 1) {
                                            this.setState({ loading: false });
                                            AsyncStorage.setItem('LOGGED', 'false');
                                            this.props.navigation.navigate('Login');
                                        } else {
                                            alert(response.data.message);
                                            this.setState({ loading: false });
                                        }
                                    }).catch((error) => {
                                        console.log(error);
                                        this.setState({ loading: false });
                                    })
                                }).catch((error) => {
                                    console.log(error);
                                    this.setState({ loading: false });
                                })
                            } else {
                                API.post('/user_login', {
                                    user_type: 'D',
                                    email: resp.user.email,
                                    password: '123456',
                                    fcm_id: this.props.device_token,
                                    device_token: this.props.device_token
                                }).then((resp) => {
                                    if (resp.data.success == 1) {
                                        if (resp.data.data.userinfo.vehicle_info == null) {
                                            alert("Please register vehicle type from Adminitrator.")
                                            this.setState({ loading: false });
                                        } else {
                                            AsyncStorage.setItem('LOGGED', 'true');
                                            AsyncStorage.setItem('USER', JSON.stringify(resp.data.data.userinfo));
                                            this.props.setUser(resp.data.data.userinfo);
                                            this.props.navigation.navigate('Root');
                                        }
                                    } else {
                                        alert(resp.data.message);
                                        this.setState({ loading: false });
                                    }
                                }).catch((error) => {
                                    console.log(error);
                                    this.setState({ loading: false });
                                })
                            }
                        }
                    }).catch(error => {
                        console.log(error);
                        alert(language.facebook_login_error);
                        this.setState({ loading: false });
                    })
            }
            else {
                alert(language.facebook_login_error);
                this.setState({ loading: false });
            }
        } catch ({ message }) {
            alert(language.facebook_login_auth_error`${message}`);
            this.setState({ loading: false });
        }
    }

    async onLogin() {
        let { email, password } = this.state;
        if (!email) {
            this.setState({ emailMsg: "Should not be empty" });
        } else {
            this.setState({ emailMsg: null })
            if (!verifyEmail(email)) {
                this.setState({ emailMsg: "Email is invailed" });
            } else {
                if (!password) {
                    this.setState({ passwordMsg: "Should not be empty" });
                } else {
                    if (!verifyLength(password, 6)) {
                        this.setState({ passwordMsg: "Enter more 6 character" });
                    } else {
                        this.setState({ passwordMsg: null, loading: true });
                        firebase.auth().signInWithEmailAndPassword(email, password).then((user) => {
                            API.post('/user_login', {
                                user_type: 'D',
                                email: email,
                                password: password,
                                fcm_id: this.props.device_token,
                                device_token: this.props.device_token
                            }).then((resp) => {
                                if (resp.data.success == 1) {
                                    if (resp.data.data.userinfo.vehicle_info == null) {
                                        alert("Please register vehicle type from Adminitrator.")
                                        this.setState({ loading: false });
                                    } else {
                                        AsyncStorage.setItem('LOGGED', 'true');
                                        AsyncStorage.setItem('USER', JSON.stringify(resp.data.data.userinfo));
                                        this.props.setUser(resp.data.data.userinfo);
                                        this.props.navigation.navigate('Root');
                                    }
                                } else {
                                    alert(resp.data.message);
                                    this.setState({ loading: false });
                                }
                            }).catch((error) => {
                                console.log(error);
                                this.setState({ loading: false });
                            })
                        }).catch((error) => {
                            console.log(error);
                            this.setState({ loading: false });
                        })
                    }
                }
            }
        }
    }

    render() {
        return (
            <View style={styles.container}>
                <StatusBar translucent backgroundColor="transparent" />
                <ImageBackground
                    source={require("@assets/images/background.png")}
                    resizeMode="stretch"
                    style={{ flex: 1 }}
                >
                    <SafeAreaView style={{ flex: 1 }}>
                        <Header title="" isStatus="login" navigation={this.props.navigation} />
                        <KeyboardAwareScrollView>
                            <View style={styles.applogoframe}>
                                <Image source={require('@assets/images/applogo.png')}
                                    style={styles.applogo}></Image>
                            </View>
                            <View style={styles.containerStyle}>
                                <View style={styles.textInputContainerStyle}>
                                    <Icon
                                        name='user-o'
                                        type='font-awesome'
                                        color={'rgba(240, 240, 240, 0.8)'}
                                        size={20}
                                        containerStyle={{ marginTop: 20 }}
                                    />
                                    <Input
                                        ref={input => (this.userInput = input)}
                                        editable={true}
                                        underlineColorAndroid={'rgba(240, 240, 240, 0)'}
                                        placeholder={"Email Address"}
                                        placeholderTextColor={'rgba(240, 240, 240, 0.8)'}
                                        keyboardType={'email-address'}
                                        secureTextEntry={false}
                                        blurOnSubmit={false}
                                        value={this.state.email}
                                        onChangeText={(text) => { this.setState({ email: text }) }}
                                        errorMessage={this.state.emailMsg == null ? null : this.state.emailMsg}
                                        onSubmitEditing={() => { this.passwordInput.focus() }}
                                        inputContainerStyle={styles.inputContainerStyle}
                                        containerStyle={styles.textInputStyle}
                                        inputStyle={styles.inputTextStyle}
                                    />
                                </View>
                                <View style={styles.textInputContainerStyle}>
                                    <Icon
                                        name='envelope-o'
                                        type='font-awesome'
                                        color={'rgba(240, 240, 240, 0.8)'}
                                        size={20}
                                        containerStyle={{ marginTop: 20 }}
                                    />
                                    <Input
                                        ref={input => (this.passwordInput = input)}
                                        editable={true}
                                        underlineColorAndroid={'rgba(240, 240, 240, 0)'}
                                        placeholder={"Password"}
                                        placeholderTextColor={'rgba(240, 240, 240, 0.8)'}
                                        value={this.state.password}
                                        secureTextEntry={true}
                                        blurOnSubmit={true}
                                        onChangeText={(text) => { this.setState({ password: text }) }}
                                        errorMessage={this.state.passwordMsg == null ? null : this.state.passwordMsg}
                                        inputContainerStyle={styles.inputContainerStyle}
                                        containerStyle={styles.textInputStyle}
                                        inputStyle={styles.inputTextStyle}
                                    />
                                </View>
                            </View>
                            <MaterialButtonYellow
                                onPress={() => this.onLogin()}
                                style={styles.materialButtonYellow}>
                                {language.login_button}
                            </MaterialButtonYellow>
                            <View style={styles.pairButton}>
                                <MaterialButtonYellow
                                    onPress={() => this.props.navigation.navigate("Signup")}
                                    style={styles.SignupStyle}>
                                    {language.signup_button}
                                </MaterialButtonYellow>
                                <TouchableOpacity
                                    onPress={() => this.FbLogin()}
                                    style={styles.FBStyle}>
                                    <Text style={{ color: '#FFF', width: '80%', textAlign: 'center', fontWeight: 'bold', fontSize: 15 }}>CONNECT</Text>
                                    <View style={styles.FBIconStyle}>
                                        <Image
                                            style={{ width: 15, height: 20, tintColor: 'rgba(255, 255, 255, 1)' }}
                                            source={images.icon_FB} />
                                    </View>
                                </TouchableOpacity>
                            </View>
                        </KeyboardAwareScrollView>
                    </SafeAreaView>
                </ImageBackground>
                <Loading loading={this.state.loading} title={"Loading..."} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    applogoframe: {
        marginTop: hp('15.0%'),
        alignSelf: "center"
    },
    applogo: {
        width: 130,
        height: 135,
        marginBottom: 20
    },

    containerStyle: {
        flexDirection: 'column',
        paddingLeft: 30,
        paddingRight: 30,
        marginBottom: 20
    },
    textInputContainerStyle: {
        flexDirection: 'row',
        width: '100%',
        height: 50,
        marginBottom: 10,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(240, 240, 240, 0.8)'
    },
    inputTextStyle: {
        color: 'rgba(240, 240, 240, 0.8)',
        fontSize: 15,
        height: 32,
        marginTop: 10
    },
    inputContainerStyle: {
        borderBottomWidth: 0,
        borderBottomColor: '#FFF'
    },

    materialButtonYellow: {
        height: 45,
        marginLeft: 30,
        marginRight: 30
    },
    pairButton: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        height: 50,
        backgroundColor: "rgba(255,255,255,0)",
        marginTop: 20,
        marginLeft: 30,
        marginRight: 30,
    },
    SignupStyle: {
        width: '48%',
        height: 45,
        borderRadius: 10,
    },
    FBStyle: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        width: '48%',
        height: 45,
        backgroundColor: "rgba(61,96,182,1)",
        borderRadius: 10,
    },
    FBIconStyle: {
        width: '20%',
        height: '100%',
        color: "#FFFFFF",
        justifyContent: "center",
        alignItems: 'center',
        backgroundColor: 'rgba(22, 61, 155, 1)',
        borderTopEndRadius: 10,
        borderBottomEndRadius: 10
    }
});

const mapStateToProps = state => {
    return {
        device_token: state.account.device_token
    }
}
const mapDispatchToProps = dispatch => {
    return {
        setUser: (data) => {
            dispatch(setUser(data))
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Login)
