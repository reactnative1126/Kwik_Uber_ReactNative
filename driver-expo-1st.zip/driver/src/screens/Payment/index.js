import React, { Component } from "react";
import {
    StyleSheet,
    SafeAreaView,
    View,
    Text,
    TouchableOpacity,
    StatusBar,
} from "react-native";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { Icon, Input } from 'react-native-elements';

import { connect } from 'react-redux';

import { Header, Loading } from '@components';
import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';

class Wallet extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false
        }
    }

    addMoney(){ 
      this.props.navigation.navigate('Money');
    }

    render() {
        return (
            <View style={styles.container}>
                <StatusBar translucent backgroundColor="transparent" />
                <SafeAreaView style={{ flex: 1 }}>
                    <Header title="Wallet" isStatus="back-circle" navigation={this.props.navigation} />
                    <View style={{ width: '100%', alignItems: 'center', height: 20 }} />
                    <View style={{ flex: 1, padding: 20, width: '100%', alignItems: 'center', backgroundColor: '#D8D8D8' }}>
                        <View style={{ height: 150, marginBottom: 12, width: wp('90.0%') }}>
                            <View style={{ flexDirection: 'row', justifyContent: "space-around", marginTop: 8 }}>
                                <View style={{ height: 120, width: wp('40.0%'), backgroundColor: '#FFFFFF', borderRadius: 8, justifyContent: 'center', flexDirection: 'column' }}>
                                    <Text style={{ textAlign: 'center', fontSize: 18 }}>{language.wallet_balance}</Text>
                                    <Text style={{ textAlign: 'center', fontSize: 25, fontWeight: '500', color: '#1CA84F' }}>{'$' + parseFloat(this.props.userinfo.wallet_balance).toFixed(2)}</Text>
                                </View>
                                <TouchableOpacity style={{ height: 120, width: wp('40.0%'), backgroundColor: '#1CA84F', borderRadius: 8, justifyContent: 'center', flexDirection: 'column' }}
                                    onPress={() => this.addMoney()}>
                                    <Icon
                                        name='add-circle'
                                        type='MaterialIcons'
                                        color='#fff'
                                        size={45}
                                        iconStyle={{ lineHeight: 48 }}
                                    />
                                    <Text style={{ textAlign: 'center', fontSize: 18, color: '#fff' }}>{language.add_money}</Text>

                                </TouchableOpacity>
                            </View>
                            <View style={{ marginVertical: 10 }}>
                                <Text style={{ paddingHorizontal: 10, fontSize: 18, fontWeight: '500', marginTop: 8 }}>{language.transaction_history_title}</Text>
                            </View>
                        </View>
                    </View>
                </SafeAreaView>
                <Loading loading={this.state.loading} title={"Loading..."} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    inputTextStyle: {
        color: 'rgba(0, 0, 0, 0.8)',
        fontSize: 15,
        // height: 32,
        // marginTop: 10
    },
    inputContainerStyle: {
        borderBottomWidth: 0,
        borderBottomColor: '#FFF'
    },
    rideBtn: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 5,
        marginBottom: 5,
        width: '100%',
        height: 50,
        borderRadius: 10,
        backgroundColor: '#00963D',
        shadowColor: '#000',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 5,
    },
});

const mapStateToProps = state => {
    return {
        logged: state.account.logged,
        userinfo: state.account.userinfo
    }
}
export default connect(mapStateToProps, undefined)(Wallet)
