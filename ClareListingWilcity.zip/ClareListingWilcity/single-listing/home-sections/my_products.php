<?php

use WilokeListingTools\Framework\Helpers\GetSettings;

global $post, $wilcityArgs;
$aProducts = GetSettings::getMyProducts($post->ID);

if (empty($aProducts)) {
    return '';
}

if (isset($wilcityArgs['maximumItemsOnHome']) && !empty($wilcityArgs['maximumItemsOnHome'])) {
    $aProducts = array_slice($aProducts, 0, $wilcityArgs['maximumItemsOnHome']);
}

$columns = apply_filters('wilcity/event/my_tickets/columns', 2);

$productsContent = do_shortcode('[products columns="'.$columns.'" ids="'.implode(',', $aProducts).'"]');

if (empty($productsContent)) {
    return '';
}

?>
<div class="content-box_module__333d9">
    <?php get_template_part('single-listing/home-sections/section-heading'); ?>
    <div class="content-box_body__3tSRB">
        <div><?php echo $productsContent; ?></div>
    </div>
</div>

