<?php
global $post, $wilcityArgs, $wilcityTabKey;
$aTags        = \WilokeListingTools\Framework\Helpers\GetSettings::getPostTerms($post->ID, 'listing_tag');
$numberOfTags = isset($wilcityArgs['maximumItemsOnHome']) && !empty($wilcityArgs['maximumItemsOnHome']) ?
    absint($wilcityArgs['maximumItemsOnHome']) : 4;
$url          = get_permalink($post->ID);
if ($aTags) :
    $wilcityTabKey = 'tags';
    ?>
    <div class="<?php echo esc_attr(apply_filters('wilcity/filter/class-prefix',
        'content-box_module__333d9 wilcity-single-listing-tag-box')); ?>">
        <?php get_template_part('single-listing/home-sections/section-heading'); ?>
        <div class="content-box_body__3tSRB">
            <div class="row">
                <?php
                $index = 0;
                foreach ($aTags as $oTag) :
                    if ($index >= $numberOfTags) {
                        break;
                    }
                    if (!empty($oTag) && !is_wp_error($oTag) && $index < $numberOfTags) : ?>
                        <div class="col-sm-4">
                            <div class="icon-box-1_module__uyg5F three-text-ellipsis mt-20 mt-sm-15">
                                <div class="icon-box-1_block1__bJ25J">
                                    <?php echo WilokeHelpers::getTermIcon($oTag,
                                        'icon-box-1_icon__3V5c0 rounded-circle', true, ['type' => $post->post_type]); ?>
                                </div>
                            </div>
                        </div>
                        <?php
                        $index++;
                    endif;
                endforeach;
                ?>
            </div>
        </div>
        <?php if ($numberOfTags < count($aTags)) : ?>
            <?php get_template_part('single-listing/home-sections/footer-seeall'); ?>
        <?php endif; ?>
    </div>
<?php endif; ?>
