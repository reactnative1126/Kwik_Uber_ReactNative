<?php
get_template_part('wilcity-term');