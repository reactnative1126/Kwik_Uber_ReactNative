    <?php do_action('wilcity/before-close-root'); ?>
    <?php if ( !is_page_template('templates/custom-login.php') ) : ?>
        </div> <!-- End wilcity-root -->
    <?php endif; ?>
    <?php wp_footer(); ?>
    </body>
</html>
