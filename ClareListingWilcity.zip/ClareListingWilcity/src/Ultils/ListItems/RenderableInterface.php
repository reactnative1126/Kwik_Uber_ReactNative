<?php

namespace Wilcity\Ultils\ListItems;

interface RenderableInterface
{
    public function render() : string;
}
