<?php

namespace Wilcity\Map;

interface InterfaceMap
{
    public function getAllConfig();
    public function getKey($key);
}
