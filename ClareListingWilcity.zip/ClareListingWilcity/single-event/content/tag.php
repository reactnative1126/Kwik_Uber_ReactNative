<?php
global $wilcityArgs;
get_template_part('single-listing/home-sections/tags');