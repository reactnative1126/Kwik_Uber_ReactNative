<?php
use WilokeListingTools\Controllers\DashboardController;
?>

<div class="dashboard-nav_module__3c0Pb list-none mt-30 mb-30">
	<?php DashboardController::printDashboardNavigation(true); ?>
</div>