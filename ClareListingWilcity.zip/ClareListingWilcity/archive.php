<?php
	get_template_part('index');
?>