<?php
return array(
	'contactForm' => '<div class="field_module__1H6kT field_style2__2Znhe mb-15 js-field">
	<div class="field_wrap__Gv92k">
		[text* your-name class:field_field__3U_Rt]
		<span class="field_label__2eCP7 text-ellipsis required">Your name</span>
		<span class="bg-color-primary"></span>
	</div>
</div>
<div class="field_module__1H6kT field_style2__2Znhe mb-15 js-field">
	<div class="field_wrap__Gv92k">
		[email* your-email class:field_field__3U_Rt]
		<span class="field_label__2eCP7 text-ellipsis required">Your name</span>
		<span class="bg-color-primary"></span>
	</div>
</div>
<div class="field_module__1H6kT field_style2__2Znhe mb-15 js-field">
	<div class="field_wrap__Gv92k">
		[text your-phone class:field_field__3U_Rt]
		<span class="field_label__2eCP7 text-ellipsis">Your Phone</span>
		<span class="bg-color-primary"></span>
	</div>
</div>
<div class="field_module__1H6kT field_style2__2Znhe field-autoHeight mb-15 js-field">
	<div class="field_wrap__Gv92k">
		[textarea message class:field_field__3U_Rt]
		<span class="field_label__2eCP7 text-ellipsis required">Message</span>
		<span class="bg-color-primary"></span>
	</div>
</div>
[submit "Submit" class:wil-btn class:wil-btn--primary class:wil-btn--md class:wil-btn--round class:wil-btn--block]'
);