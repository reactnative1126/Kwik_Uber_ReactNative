const functions = require('firebase-functions');

const stripe = require('stripe')('sk_live_5AruXF8E5oB8AB8fl2W8do8s00KfjoELh4');

exports.completePaymentWithStripe = functions.https.onRequest((request, response) => {
    return stripe.charges.create({
            amount: request.body.amount,
            currency: request.body.currency,
            source: request.body.token,
        }).then((charge) => {
            return response.send(charge);
        }).catch((error) => {
            return console.log(error);
        });
});

