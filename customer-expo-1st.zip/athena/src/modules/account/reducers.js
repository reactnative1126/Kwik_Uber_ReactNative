import types from './types';

const initialState = {
    logged: false,
    device_token: null,
    userinfo: {
        user_id: null,
        api_token: "",
        fcm_id: null,
        device_token: null,
        socialmedia_uid: null,
        user_name: "",
        user_type: "C",
        mobno: "",
        phone_code: "",
        email: "",
        gender: 1,
        password: "",
        profile_pic: null,
        status: 1,
        wallet_balance: 0,
        timestamp: ""
    }
}

export default function accountReducer(state = initialState, action) {
    switch (action.type) {
        case types.SET_USER:
            return {
                ...state,
                logged: true,
                userinfo: action.payload
            };
        case types.SET_DEVICE_TOKEN:
            return {
                ...state,
                device_token: action.payload
            };
        case types.SIGN_OUT:
            return {
                ...state,
                logged: false,
                userinfo: initialState
            }

        default:
            return state;
    }
}