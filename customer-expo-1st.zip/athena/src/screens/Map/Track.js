import React from 'react';
import {
    Platform,
    StyleSheet,
    SafeAreaView,
    StatusBar,
    View,
    Dimensions,
    TouchableOpacity,
    Text
} from 'react-native';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { Icon, Button, Avatar } from 'react-native-elements';
import MapView, { Marker, AnimatedRegion, Polyline, PROVIDER_GOOGLE } from "react-native-maps";
import haversine from "haversine";

import { connect } from 'react-redux';

import { Header, Loading } from '@components';
import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';

const { width, height } = Dimensions.get('window');
const ASPECT_RATIO = width / height;
const LATITUDE = 37.771707;
const LONGITUDE = -122.4053769;
const LATITUDE_DELTA = 0.055;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

class Track extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            latitude: parseFloat(this.props.navigation.getParam('data').riderequest_info.dest_lat),
            longitude: parseFloat(this.props.navigation.getParam('data').riderequest_info.dest_long),
            routeCoordinates: [],
            distanceTravelled: 0,
            prevLatLng: {},
            coordinate: new AnimatedRegion({
                latitude: parseFloat(this.props.navigation.getParam('data').riderequest_info.dest_lat),
                longitude: parseFloat(this.props.navigation.getParam('data').riderequest_info.dest_long),
                latitudeDelta: 0,
                longitudeDelta: 0
            })
        };
    }
    componentDidMount() {
        const { coordinate } = this.state;

        this.watchID = navigator.geolocation.watchPosition(
            position => {
                const { routeCoordinates, distanceTravelled } = this.state;
                const { latitude, longitude } = position.coords;
                const newCoordinate = {
                    latitude,
                    longitude
                };
                // alert(JSON.stringify(newCoordinate));
                // if (Platform.OS === "android") {
                //     if (this.marker) {
                //         this.marker._component.animateMarkerToCoordinate(
                //             newCoordinate,
                //             500
                //         );
                //     }
                // } else {
                //     coordinate.timing(newCoordinate).start();
                // }
                coordinate.timing(newCoordinate).start();
                this.setState({
                    latitude, longitude,
                    routeCoordinates: routeCoordinates.concat([newCoordinate]),
                    distanceTravelled: distanceTravelled + this.calcDistance(newCoordinate),
                    prevLatLng: newCoordinate
                });
                console.log(routeCoordinates);
            },
            error => console.log(error),
            {
                enableHighAccuracy: true,
                timeout: 20000,
                maximumAge: 1000,
                distanceFilter: 10
            }
        );
    }

    componentWillUnmount() {
        navigator.geolocation.clearWatch(this.watchID);
    };

    getMapRegion = () => ({
        latitude: this.state.latitude,
        longitude: this.state.longitude,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA
    });

    calcDistance = newLatLng => {
        const { prevLatLng } = this.state;
        return haversine(prevLatLng, newLatLng) || 0;
    };

    render() {
        return (
            <View style={styles.mainViewStyle}>
                <StatusBar translucent backgroundColor="transparent" barStyle="dark-content" />
                <SafeAreaView style={{ flex: 1 }}>
                    <Header title="" isStatus="menu" navigation={this.props.navigation} />
                    <MapView
                        style={styles.map}
                        provider={PROVIDER_GOOGLE}
                        showUserLocation
                        followUserLocation
                        loadingEnabled
                        region={this.getMapRegion()}
                    >
                        <MapView.Polyline
                            coordinates={this.state.coords ? this.state.coords : [{ latitude: 0.00, longitude: 0.00 }]}
                            strokeWidth={5}
                            strokeColor={'#FF0000'}
                        />
                        <Polyline coordinates={this.state.routeCoordinates} strokeWidth={5} />
                        <Marker.Animated
                            ref={marker => {
                                this.marker = marker;
                            }}
                            image={require('@assets/images/track_Car.png')}
                            coordinate={new AnimatedRegion({
                                latitude: this.state.latitude ? this.state.latitude : 0.00,
                                longitude: this.state.longitude ? this.state.longitude : 0.00,
                                latitudeDelta: LATITUDE_DELTA,
                                longitudeDelta: LONGITUDE_DELTA
                            })}
                        >
                        </Marker.Animated>
                        <Marker
                            image={require('@assets/images/rsz_2red_pin.png')}
                            coordinate={{
                                latitude: this.props.navigation.getParam('data').source_lat ? parseFloat(this.props.navigation.getParam('data').source_lat) : 0.00,
                                longitude: this.props.navigation.getParam('data').source_long ? parseFloat(this.props.navigation.getParam('data').source_long) : 0.00
                            }}
                        >
                        </Marker>
                        <Marker
                            image={require('@assets/images/rsz_2red_pin.png')}
                            coordinate={{
                                latitude: this.props.navigation.getParam('data').dest_lat ? parseFloat(this.props.navigation.getParam('data').dest_lat) : 0.00,
                                longitude: this.props.navigation.getParam('data').dest_long ? parseFloat(this.props.navigation.getParam('data').dest_long) : 0.00
                            }}
                        >
                        </Marker>
                    </MapView>
                    <View style={styles.buttonContainer}>
                        <TouchableOpacity style={[styles.bubble, styles.button]}>
                            <Text style={styles.bottomBarContent}>
                                {parseFloat(this.state.distanceTravelled).toFixed(2)} km
                                </Text>
                        </TouchableOpacity>
                    </View>
                </SafeAreaView>
            </View >
        );
    }
}

const styles = StyleSheet.create({
    mainViewStyle: {
        flex: 1,
        backgroundColor: colors.WHITE,
    },
    container: {
        ...StyleSheet.absoluteFillObject,
        justifyContent: "flex-end",
        alignItems: "center"
    },
    map: {
        ...StyleSheet.absoluteFillObject
    },
    bubble: {
        flex: 1,
        backgroundColor: "rgba(255,255,255,0.7)",
        paddingHorizontal: 18,
        paddingVertical: 12,
        borderRadius: 20
    },
    latlng: {
        width: 200,
        alignItems: "stretch"
    },
    button: {
        width: 80,
        paddingHorizontal: 12,
        alignItems: "center",
        marginHorizontal: 10
    },
    buttonContainer: {
        flexDirection: "row",
        marginVertical: 20,
        backgroundColor: "transparent"
    }
});

const mapStateToProps = state => {
    return {
        logged: state.account.logged,
        userinfo: state.account.userinfo
    }
}
export default connect(mapStateToProps, undefined)(Track)