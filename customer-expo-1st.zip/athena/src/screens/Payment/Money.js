import React, { Component } from "react";
import {
    StyleSheet,
    SafeAreaView,
    View,
    Text,
    TouchableOpacity,
    StatusBar,
    TextInput,
    FlatList,
    ScrollView,
    Alert
} from "react-native";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { Icon, Input } from 'react-native-elements';
import { CreditCardInput } from "react-native-credit-card-input";
// import { PaymentsStripe as Stripe } from 'expo-payments-stripe';
// Stripe.setOptionsAsync({
//     publishableKey: 'pk_live_j1YP5wmedvO2mP7MHYRSu6Lt004Q1NidPJ'
// });

import { connect } from 'react-redux';

import { Header, Loading } from '@components';
import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
// import API from '@services/API';
import axios from "axios";

class Money extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            amount: '5',
            token: null,
            qickMoney: [{ amount: '5', selected: false }, { amount: '10', selected: false }, { amount: '20', selected: false }, { amount: '50', selected: false }, { amount: '100', selected: false }],
        }
    }
    onChange = formData => {
        if (formData.valid == true && formData.status.number == "valid" && formData.status.expiry == "valid" && formData.status.cvc == "valid") {
            Alert.alert(
                'Charge money from your card...',
                'Would you charge money from your card to this wallet?',
                [
                    {
                        text: 'CANCEL',
                        onPress: () => {
                            return
                        },
                        style: 'cancel'
                    },
                    {
                        text: 'Charge',
                        // onPress: async () => {
                        //     try {
                        //         this.setState({ loading: true, token: null });
                        //         const params = {
                        //             number: formData.values.number,
                        //             expMonth: parseInt(formData.values.expiry.split('/')[0]),
                        //             expYear: parseInt(formData.values.expiry.split('/')[1]),
                        //             cvc: formData.values.cvc
                        //         };
                        //         const token = await Stripe.createTokenWithCardAsync(params);
                        //         axios({
                        //             method: 'POST',
                        //             url: 'https://us-central1-kwik-35758.cloudfunctions.net/completePaymentWithStripe',
                        //             data: {
                        //                 amount: 100,
                        //                 currency: 'usd',
                        //                 token: token.tokenId
                        //             }
                        //         }).then(response => {
                        //             alert(response)
                        //             this.setState({ loading: false });
                        //         }).catch(error => {
                        //             alert(error)
                        //             this.setState({ loading: false });
                        //         })
                        //     } catch (error) {
                        //         this.setState({ loading: false });
                        //     }
                        // },
                    }
                ],
            )
        }
    };

    render() {
        return (
            <View style={styles.container}>
                <StatusBar translucent backgroundColor="transparent" />
                <SafeAreaView style={{ flex: 1 }}>
                    <Header title="Add Money" isStatus="back-circle" navigation={this.props.navigation} />
                    <View style={{ width: '100%', alignItems: 'center', height: 20 }} />
                    <View style={{ flex: 1, padding: 20, width: '100%', alignItems: 'center', backgroundColor: '#D8D8D8' }}>
                        <CreditCardInput
                            autoFocus
                            requiresCVC
                            labelStyle={styles.label}
                            inputStyle={styles.input}
                            validColor={"black"}
                            invalidColor={"red"}
                            placeholderColor={"darkgray"}
                            onChange={this.onChange} />
                    </View>
                </SafeAreaView>
                <Loading loading={this.state.loading} title={"Loading..."} />
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    bodyContainer: {
        flex: 1,
        flexDirection: 'column',
        paddingHorizontal: 12
    },
    walletbalText: {
        width: '100%',
        fontSize: 17
    },
    balance: {
        fontWeight: 'bold'
    },
    inputTextStyle: {
        marginTop: 10,
        width: '100%',
        height: 50,
        borderBottomColor: 'gray',
        borderBottomWidth: 1,
        fontSize: 30
    },
    buttonWrapper2: {
        marginBottom: 10,
        marginTop: 18,
        height: 55,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: colors.GREY.default,
        borderRadius: 8,
    },
    buttonTitle: {
        color: '#fff',
        fontSize: 18,
    },
    quickMoneyContainer: {
        marginTop: 18,
        flexDirection: 'row',
        paddingVertical: 4,
        paddingLeft: 4,
    },
    boxView: {
        height: 40,
        width: 55,
        borderRadius: 6,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 8,
        shadowColor: '#000',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 5,
    },
    rideBtn: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
        marginBottom: 5,
        width: '100%',
        height: 50,
        borderRadius: 10,
        backgroundColor: '#00963D',
        shadowColor: '#000',
        shadowOpacity: 0.8,
        shadowOffset: { height: 1, width: 1 },
        shadowRadius: 2,
        elevation: 5,
    },
    label: {
        color: "black",
        fontSize: 12,
    },
    input: {
        fontSize: 16,
        color: "black",
    },
});

const mapStateToProps = state => {
    return {
        logged: state.account.logged,
        userinfo: state.account.userinfo
    }
}
export default connect(mapStateToProps, undefined)(Money)
