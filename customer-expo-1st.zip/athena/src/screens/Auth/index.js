import React, { Component } from "react";
import {
  ActivityIndicator,
  StyleSheet,
  View,
  AsyncStorage,
  Alert,
} from 'react-native';
import { Platform } from 'react-native';
import { Notifications } from 'expo';
import Constants from 'expo-constants';
import * as Permissions from 'expo-permissions';
import { Audio } from 'expo-av';
import { StackActions, NavigationActions } from 'react-navigation';

import { connect } from 'react-redux';
import { setUser, setDeviceToken } from '@modules/account/actions';

import { colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';

class AuthStart extends Component {
  constructor(props) {
    super(props);

  }

  async componentWillMount() {
    this.registerForPushNotificationsAsync();
    if (await AsyncStorage.getItem('LOGGED') === 'true') {
      let userinfo = await AsyncStorage.getItem('USER');
      this.props.setUser(userinfo);
      this.props.navigation.navigate('Root');
    } else {
      this.props.navigation.navigate('Auth');
    }
  }

  async registerForPushNotificationsAsync() {
    if (Constants.isDevice) {
      const { status: existingStatus } = await Permissions.getAsync(
        Permissions.NOTIFICATIONS
      );
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await Permissions.askAsync(Permissions.NOTIFICATIONS);
        finalStatus = status;
      }

      if (finalStatus !== 'granted') {
        alert('Failed to get push token for push notification!');
        return;
      }
      if (Platform.OS === 'android') {
        Notifications.createChannelAndroidAsync('default', {
          name: 'Android Channel',
          sound: true,
          vibrate: true
        });
      }
      let deviceToken = await Notifications.getExpoPushTokenAsync();
      this.props.setDeviceToken(deviceToken);
    } else {
      alert('Must use physical device for Push Notifications');
    }
    this.notificationListener = Notifications.addListener(this.notificationListen);
  }

  notificationListen = async notification => {
    console.log(notification)
    if (notification.data.data.success == 1) {
      if (notification.data.data.key === "driver_unavailable_notification") {
        Alert.alert(
          notification.data.data.title,
          notification.data.data.description,
          [
            {
              text: 'GOT IT',
              onPress: () => {
                const resetAction = StackActions.reset({
                  index: 0,
                  actions: [NavigationActions.navigate({ routeName: 'Map' })],
                });
                this.props.navigation.dispatch(resetAction);
              },
            }
          ],
        )
      } else if (notification.data.data.key === "accept_ride_notification") {
        console.log(notification.data.data)
        Alert.alert(
          notification.data.data.title,
          notification.data.data.description,
          [
            {
              text: 'OK',
              onPress: () => {
                const navigatieAction = NavigationActions.navigate({
                  routeName: 'Track',
                  params: {
                    data: notification.data.data.data
                  }
                });
                this.props.navigation.dispatch(navigatieAction);
              },
            }
          ],
        )
      } else if (notification.data.data.key === "ride_started_notification") {
        Alert.alert(
          notification.data.data.title,
          notification.data.data.description,
          [
            {
              text: 'OK',
            }
          ],
        )
      } else if (notification.data.data.key === "ride_completed_notification") {
        Alert.alert(
          notification.data.data.title,
          notification.data.data.description,
          [
            {
              text: 'OK',
            }
          ],
        )
      } else if (notification.data.data.key === "confirm_payment_notification") {
        Alert.alert(
          notification.data.data.title,
          notification.data.data.description,
          [
            {
              text: 'OK',
              onPress: () => {
                const navigatieAction = NavigationActions.navigate({
                  routeName: 'Rating',
                  params: {
                    data: notification.data.data.data
                  }
                });
                this.props.navigation.dispatch(navigatieAction);
              },
            }
          ],
        )
      }
    }
    const soundObject = new Audio.Sound();
    try {
      await soundObject.loadAsync(require('@assets/sounds/car_horn.wav'));
      await soundObject.playAsync();
    } catch (error) {
      console.log("Unable to play shound");
    }
  };

  // Render any loading content that you like here
  render() {
    return (
      <View style={styles.IndicatorStyle}>
        <ActivityIndicator size="large" />
      </View>
    );
  }
}

//Screen Styling
const styles = StyleSheet.create({
  IndicatorStyle: {
    flex: 1,
    justifyContent: "center"
  }
})

const mapDispatchToProps = dispatch => {
  return {
    setUser: (data) => {
      dispatch(setUser(data))
    },
    setDeviceToken: (data) => {
      dispatch(setDeviceToken(data))
    }
  }
}
export default connect(undefined, mapDispatchToProps)(AuthStart)