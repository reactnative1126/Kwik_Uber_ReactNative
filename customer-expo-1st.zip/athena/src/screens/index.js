
import AuthStart from './Auth';
import Login from './Auth/Login';
import Signup from './Auth/Signup';
import Forgot from './Auth/Forgot';
import Map from './Map';
import Track from './Map/Track';
import Search from './Search';
import Confirm from './Confirm';
import Accepts from './Accepts';
import Message from './Message';

import Profile from './Profile';
import Password from './Password';

import Booking from './Booking';
import Contact from './Contact';
import About from './About';
import Rating from './Rating';
import Details from './Details';

import Wallet from './Payment';
import Money from './Payment/Money';
import Payment from './Payment/Payment';

export {
    AuthStart, Login, Signup, Forgot,
    Map, Search, Confirm, Accepts, Message, Track,
    Profile, Password,
    Booking,
    Contact,
    About, Rating, Details,
    Wallet, Money, Payment
};