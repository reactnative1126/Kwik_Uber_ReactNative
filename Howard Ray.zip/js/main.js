	//animate css add
	$(window).on('load scroll resize', function() {	
		$('.home_title').anisview({
			animation: 'slideInLeft',
		});	
		$('.second_section_box1').anisview({
			animation: 'slideInLeft',
		});
		$('.second_section_box2').anisview({
			animation: 'slideInDown',	
		});
		$('.second_section_box3').anisview({
			animation: 'slideInLeft',	
		});
		$('.team_dcp').anisview({
			animation: 'slideInLeft',	
        });
        $('.blog_dcp').anisview({
			animation: 'slideInRight',	
		});
    });
    

    