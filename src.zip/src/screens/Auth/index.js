import React, { Component } from "react";
import {
    StatusBar,
    StyleSheet,
    ImageBackground,
    Image,
    AsyncStorage,
} from 'react-native';

import { connect } from 'react-redux';
import { setUser, setDeviceToken } from '@modules/account/actions';
import { theme, colors } from '@constants/theme';
import images from '@constants/images';
import configs from '@constants/configs';
import language from '@constants/language';
import API from '@services/API';
import { fcm } from '@services/FCM';

class Splash extends Component {
    constructor(props) {
        super(props);
        this.fcmNotification = null;
        this.state = {

        }
    }

    async componentWillMount() {
        this.fcmNotification = fcm;
        this.fcmNotification.register(this.onRegister, this.onNotification, this.onOpenNotification);
        setTimeout(() => {
            if (AsyncStorage.getItem('LOGGED') === "true") {
                // this.props.logged(true);
                this.props.setUser(AsyncStorage.getItem('USER'));
                this.props.navigation.navigate('App');
            } else {
                // this.props.logged(false);
                this.props.navigation.navigate('Auth');
            }
        }, 3000);
    }

    onRegister(token){
        console.log("[Notification] onRegister: ", token);
    }
    
    onNotification(notify){
        console.log("[Notification] onNotification: ", notify);
    }
    
    onOpenNotification(notify){
        console.log("[Notification] onOpenNotification: ", notify);
    }

    render() {
        return (
            <ImageBackground style={style.container} source={images.img_background}>
                <StatusBar hidden />
                <Image source={images.img_logo} style={{ width: 150, height: 150 }} />
            </ImageBackground>
        )
    }
}

const style = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
});

const mapDispatchToProps = dispatch => {
    return {
        setUser: (data) => {
            dispatch(setUser(data))
        },
        setDeviceToken: (data) => {
            dispatch(setDeviceToken(data))
        }
    }
}
export default connect(undefined, mapDispatchToProps)(Splash)