import React from 'react';
import {
    StatusBar,
    StyleSheet,
    View,
    Text,
    AsyncStorage,
} from 'react-native';

export default class Map extends React.Component {

    render(){
        return(
            <View>
                <Text>000</Text>
            </View>
        )
    }
}