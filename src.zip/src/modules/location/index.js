import locationReducer from './reducers';

export { default as locationActionTypes } from './types';
export { default as locationActions } from './actions';

export default locationReducer;