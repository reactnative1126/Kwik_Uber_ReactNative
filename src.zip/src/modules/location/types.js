export default {
    SET_SEARCH: 'SET_SEARCH',
    SET_OLD: 'SET_OLD'
}