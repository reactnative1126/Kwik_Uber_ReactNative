export default {
    SET_USER: 'SET_USER',
    SIGN_OUT: 'SIGN_OUT',
    SET_DEVICE_TOKEN: 'SET_DEVICE_TOKEN'
}