import bookingReducer from './reducers';

export { default as bookingActionTypes } from './types';
export { default as bookingActions } from './actions';

export default bookingReducer;