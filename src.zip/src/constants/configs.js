export default {
    baseURL: "http://kwikbookings.com",
    apiURL: "http://kwikbookings.com/api",
    // baseURL: "http://192.168.100.52",
    // apiURL: "http://192.168.100.52/api",
    google_map_key: 'AIzaSyCXU9mYBzIVbb3ljhHbwWj1IHAP373_RO4',
    cloudURL: 'https://us-central1-kwik-35758.cloudfunctions.net',
    databaseURL: 'https://kwik-35758.firebaseio.com',
    FIREBASE_API_KEY: "AIzaSyAUp82z2O05zrXAnH8IZ_Nc_NRFg-kPIe4",
    latitude: 18.008841,
    longitude: -76.784286,
    delta: 0.029
}