import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { DrawerContent } from './content.js';

import HomeStack from '../StackNavigator/HomeStackNavigator';

const Drawer = createDrawerNavigator();
export default function DrawerNavigator() {
    return (
        <Drawer.Navigator drawerContent={props => <DrawerContent {...props} />} initialRouteName="Home" >
            <Drawer.Screen name="Home" component={HomeStack} />
            {/* <Drawer.Screen name="Book YOUR RIDE" component={HomeStack} />
            <Drawer.Screen name="RIDE HISTORY" component={HomeStack} />
            <Drawer.Screen name="PAYMENT" component={HomeStack} />
            <Drawer.Screen name="SUPPORT AND FAQ" component={HomeStack} />
            <Drawer.Screen name="ABOUT US" component={HomeStack} /> */}
        </Drawer.Navigator>
    )
}
